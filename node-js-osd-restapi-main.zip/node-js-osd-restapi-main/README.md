# Project Restapi

The project is a skeleton of a REST API project
working with the World database in an adapted
Sqlite3 edition.

It is incomplete, and meant to be incomplete as
it serves as a starting point for students to
improve it in an educational setting.

## Author

*Niels Müller Larsen*

## License

Copyright © 2025-present Niels Müller Larsen
Released under the [MIT License](LICENSE).

# EMAIL : nmla@iba.dk
